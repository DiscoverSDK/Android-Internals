#include<stdio.h>

void main()
{
int *p=NULL;
int x=90;
x++; 

printf("hello world %d\n",x);
*p=999;

}
